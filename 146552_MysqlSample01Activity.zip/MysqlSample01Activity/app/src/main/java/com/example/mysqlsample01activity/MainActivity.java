package com.example.mysqlsample01activity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends Activity {

   /* private static final String url = "jdbc:mysql://sql4.freemysqlhosting.net/dbname";
    private static final String user = "username";
    private static final String pass = "password"; */
    private static final String url = "jdbc:mysql://10.6.73.64:3306/test";
    private static final String user = "test123";
    private static final String pass = "test";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        testDB();
    }

    public void testDB() {
    	TextView tv = (TextView)this.findViewById(R.id.text_view);
        try {
           
        	StrictMode.ThreadPolicy policy = 
        		    new StrictMode.ThreadPolicy.Builder().permitAll().build();      
        		        StrictMode.setThreadPolicy(policy);
     
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection con = DriverManager.getConnection(url, user, pass);

            String result = "Database connection success\n";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from Instructor");
            ResultSetMetaData rsmd = rs.getMetaData();

            while(rs.next()) {
            	result += rsmd.getColumnName(1) + ": " + rs.getString(1) + "\n";
            	result += rsmd.getColumnName(2) + ": " + rs.getInt(2) + "\n";
            	result += rsmd.getColumnName(3) + ": " + rs.getString(3) + "\n";
            }
            tv.setText(result);
        }
        catch(Exception e) {
            e.printStackTrace();
            tv.setText(e.toString());
        }   

    }
}